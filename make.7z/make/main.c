#include <stdio.h>

int main (void)
{
    printf("Hello world");
    printf("Hello world2");
    printf("Hello world3");
    
}
